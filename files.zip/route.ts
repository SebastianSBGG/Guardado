import { NextRequest, NextResponse } from "next/server"

// Cambia esto por la IP o dominio de tu VPS
const VPS_URL = process.env.VPS_URL || "http://TU-IP-VPS:3000"
// Clave secreta para autenticarse con el VPS (opcional pero recomendado)
const VPS_API_KEY = process.env.VPS_API_KEY || ""

export async function GET(req: NextRequest) {
  const action = req.nextUrl.searchParams.get("action") || "status"

  try {
    const res = await fetch(`${VPS_URL}/api/${action}`, {
      headers: {
        "x-api-key": VPS_API_KEY,
        "Content-Type": "application/json",
      },
      // Timeout de 5 segundos
      signal: AbortSignal.timeout(5000),
    })

    if (!res.ok) throw new Error(`VPS respondió con ${res.status}`)

    const data = await res.json()
    return NextResponse.json(data)
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Error desconocido"
    return NextResponse.json(
      { online: false, error: message },
      { status: 503 }
    )
  }
}

export async function POST(req: NextRequest) {
  const action = req.nextUrl.searchParams.get("action") || "send"
  const body = await req.json()

  try {
    const res = await fetch(`${VPS_URL}/api/${action}`, {
      method: "POST",
      headers: {
        "x-api-key": VPS_API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(8000),
    })

    if (!res.ok) throw new Error(`VPS respondió con ${res.status}`)

    const data = await res.json()
    return NextResponse.json(data)
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Error desconocido"
    return NextResponse.json(
      { ok: false, error: message },
      { status: 503 }
    )
  }
}
