"use client"

import { useState, useEffect, useCallback } from "react"
import {
  Bot, Wifi, WifiOff, QrCode, RefreshCw, Send,
  Terminal, Users, MessageSquare, Zap, ArrowLeft,
  CheckCircle, XCircle, Clock, Activity,
} from "lucide-react"

// ─── Tipos ────────────────────────────────────────────────────────────────────
interface BotStatus {
  online: boolean
  connected: boolean   // sesión de WhatsApp activa
  qr?: string          // base64 del QR cuando no está conectado
  uptime?: number      // segundos corriendo
  messagesHandled?: number
  activeChats?: number
  error?: string
}

// ─── Helper: formatear uptime ─────────────────────────────────────────────────
function formatUptime(seconds: number) {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = seconds % 60
  if (h > 0) return `${h}h ${m}m`
  if (m > 0) return `${m}m ${s}s`
  return `${s}s`
}

// ─── Stat card ────────────────────────────────────────────────────────────────
function StatCard({
  icon, value, label, color = "accent",
}: {
  icon: React.ReactNode
  value: string | number
  label: string
  color?: "accent" | "success" | "warning" | "destructive"
}) {
  const colorMap = {
    accent:      "text-accent border-accent/20 bg-accent/5",
    success:     "text-success border-success/20 bg-success/5",
    warning:     "text-warning border-warning/20 bg-warning/5",
    destructive: "text-destructive border-destructive/20 bg-destructive/5",
  }
  return (
    <div className="rounded-2xl border border-border bg-card p-5 flex items-center gap-4">
      <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border ${colorMap[color]}`}>
        {icon}
      </div>
      <div>
        <div className="font-mono text-2xl font-bold text-foreground">{value}</div>
        <div className="text-xs text-muted-foreground">{label}</div>
      </div>
    </div>
  )
}

// ─── Panel principal ──────────────────────────────────────────────────────────
export function BotSection({ onGoApi }: { onGoApi: () => void }) {
  const [status, setStatus]         = useState<BotStatus | null>(null)
  const [loading, setLoading]       = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [sendNum, setSendNum]       = useState("")
  const [sendMsg, setSendMsg]       = useState("")
  const [sending, setSending]       = useState(false)
  const [sendResult, setSendResult] = useState<string | null>(null)
  const [logs, setLogs]             = useState<string[]>([
    "Panel iniciado...",
    "Conectando con VPS...",
  ])

  const addLog = useCallback((msg: string) => {
    const time = new Date().toLocaleTimeString("es-CL")
    setLogs((prev) => [`[${time}] ${msg}`, ...prev].slice(0, 50))
  }, [])

  const fetchStatus = useCallback(async (silent = false) => {
    if (!silent) setLoading(true)
    else setRefreshing(true)
    try {
      const res = await fetch("/api/bot?action=status")
      const data: BotStatus = await res.json()
      setStatus(data)
      addLog(data.online
        ? data.connected
          ? "✅ Bot online y conectado a WhatsApp"
          : "⚠️ Bot online pero esperando escaneo QR"
        : "❌ VPS sin respuesta")
    } catch {
      setStatus({ online: false, connected: false, error: "Sin respuesta del VPS" })
      addLog("❌ Error al conectar con VPS")
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }, [addLog])

  // Auto-refresh cada 30 segundos
  useEffect(() => {
    fetchStatus()
    const interval = setInterval(() => fetchStatus(true), 30_000)
    return () => clearInterval(interval)
  }, [fetchStatus])

  const handleSend = async () => {
    if (!sendNum.trim() || !sendMsg.trim()) return
    setSending(true)
    setSendResult(null)
    try {
      const res = await fetch("/api/bot?action=send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ numero: sendNum.trim(), mensaje: sendMsg.trim() }),
      })
      const data = await res.json()
      if (data.ok) {
        setSendResult("✅ Mensaje enviado correctamente")
        addLog(`📤 Mensaje enviado a ${sendNum}`)
        setSendMsg("")
      } else {
        setSendResult(`❌ Error: ${data.error || "Respuesta inválida"}`)
        addLog(`❌ Fallo al enviar a ${sendNum}`)
      }
    } catch {
      setSendResult("❌ Error de conexión con el VPS")
    } finally {
      setSending(false)
    }
  }

  // ── Estado de carga inicial ──────────────────────────────────────────────
  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="h-12 w-12 rounded-2xl border border-accent/30 bg-accent/10 flex items-center justify-center animate-pulse">
            <Bot className="h-6 w-6 text-accent" />
          </div>
          <p className="text-sm text-muted-foreground">Conectando con el VPS...</p>
        </div>
      </div>
    )
  }

  const isOnline    = status?.online    ?? false
  const isConnected = status?.connected ?? false

  return (
    <div className="min-h-screen bg-background">

      {/* ── Top bar ─────────────────────────────────────────────────────── */}
      <div className="sticky top-0 z-50 flex items-center justify-between px-4 py-3 bg-background/80 backdrop-blur-sm border-b border-border">
        <button
          onClick={onGoApi}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <Zap className="h-4 w-4 text-accent" />
          <span>Sebastian API</span>
        </button>

        <div className="flex items-center gap-2">
          {/* Indicador de estado */}
          <span className={`flex h-2 w-2 rounded-full ${
            isConnected ? "bg-success animate-pulse" :
            isOnline    ? "bg-warning animate-pulse" :
                          "bg-destructive"
          }`} />
          <span className="text-xs text-muted-foreground hidden sm:inline">
            {isConnected ? "Conectado" : isOnline ? "Sin sesión" : "Offline"}
          </span>

          <button
            onClick={() => fetchStatus(true)}
            disabled={refreshing}
            className="ml-2 flex items-center gap-1.5 rounded-lg border border-border bg-secondary px-3 py-1.5 text-xs text-foreground hover:border-accent transition-all disabled:opacity-50"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? "animate-spin" : ""}`} />
            Actualizar
          </button>
        </div>
      </div>

      <div className="mx-auto max-w-5xl px-4 py-8 space-y-6">

        {/* ── Header ──────────────────────────────────────────────────────── */}
        <div className="flex items-center gap-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-accent/30 bg-accent/10">
            <Bot className="h-7 w-7 text-accent" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Panel del Bot</h1>
            <p className="text-sm text-muted-foreground">Bailey WhatsApp · VPS Control</p>
          </div>
        </div>

        {/* ── Stats ───────────────────────────────────────────────────────── */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <StatCard
            icon={isOnline ? <Wifi className="h-5 w-5" /> : <WifiOff className="h-5 w-5" />}
            value={isOnline ? "Online" : "Offline"}
            label="VPS"
            color={isOnline ? "success" : "destructive"}
          />
          <StatCard
            icon={<Activity className="h-5 w-5" />}
            value={isConnected ? "Activo" : "Sin sesión"}
            label="WhatsApp"
            color={isConnected ? "success" : "warning"}
          />
          <StatCard
            icon={<Clock className="h-5 w-5" />}
            value={status?.uptime ? formatUptime(status.uptime) : "—"}
            label="Uptime"
            color="accent"
          />
          <StatCard
            icon={<MessageSquare className="h-5 w-5" />}
            value={status?.messagesHandled ?? "—"}
            label="Mensajes"
            color="accent"
          />
        </div>

        {/* ── QR o estado conectado ────────────────────────────────────────── */}
        {isOnline && !isConnected && status?.qr && (
          <div className="rounded-2xl border border-warning/30 bg-warning/5 p-6 flex flex-col items-center gap-4">
            <div className="flex items-center gap-2 text-warning text-sm font-medium">
              <QrCode className="h-4 w-4" />
              Escanea este QR con WhatsApp para conectar el bot
            </div>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={`data:image/png;base64,${status.qr}`}
              alt="QR WhatsApp"
              className="h-52 w-52 rounded-xl border border-border bg-white p-2"
            />
            <p className="text-xs text-muted-foreground">
              Abre WhatsApp → Dispositivos vinculados → Vincular dispositivo
            </p>
          </div>
        )}

        {isConnected && (
          <div className="rounded-2xl border border-success/30 bg-success/5 p-5 flex items-center gap-3">
            <CheckCircle className="h-5 w-5 text-success shrink-0" />
            <div>
              <p className="text-sm font-medium text-success">Bot conectado a WhatsApp</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Chats activos: {status?.activeChats ?? "—"}
              </p>
            </div>
          </div>
        )}

        {!isOnline && (
          <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-5 flex items-center gap-3">
            <XCircle className="h-5 w-5 text-destructive shrink-0" />
            <div>
              <p className="text-sm font-medium text-destructive">VPS sin respuesta</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Verifica que el bot esté corriendo en tu VPS
              </p>
            </div>
          </div>
        )}

        {/* ── Enviar mensaje ───────────────────────────────────────────────── */}
        <div className="rounded-2xl border border-border bg-card p-6 space-y-4">
          <div className="flex items-center gap-3">
            <Send className="h-5 w-5 text-accent" />
            <h2 className="text-base font-semibold text-foreground">Enviar mensaje</h2>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <label className="text-xs text-muted-foreground">
                Número (con código país, ej: 56912345678)
              </label>
              <input
                value={sendNum}
                onChange={(e) => setSendNum(e.target.value)}
                placeholder="56912345678"
                className="w-full rounded-xl border border-border bg-secondary px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20 transition-all"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs text-muted-foreground">Mensaje</label>
              <input
                value={sendMsg}
                onChange={(e) => setSendMsg(e.target.value)}
                placeholder="Escribe el mensaje..."
                className="w-full rounded-xl border border-border bg-secondary px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20 transition-all"
              />
            </div>
          </div>

          <button
            onClick={handleSend}
            disabled={sending || !isConnected || !sendNum || !sendMsg}
            className="flex items-center gap-2 rounded-xl bg-accent px-5 py-2.5 text-sm font-medium text-white transition-all hover:bg-accent/90 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {sending
              ? <RefreshCw className="h-4 w-4 animate-spin" />
              : <Send className="h-4 w-4" />
            }
            {sending ? "Enviando..." : "Enviar"}
          </button>

          {sendResult && (
            <p className={`text-sm ${sendResult.startsWith("✅") ? "text-success" : "text-destructive"}`}>
              {sendResult}
            </p>
          )}

          {!isConnected && (
            <p className="text-xs text-muted-foreground">
              El bot debe estar conectado a WhatsApp para enviar mensajes.
            </p>
          )}
        </div>

        {/* ── Logs ─────────────────────────────────────────────────────────── */}
        <div className="rounded-2xl border border-border bg-card p-6 space-y-4">
          <div className="flex items-center gap-3">
            <Terminal className="h-5 w-5 text-accent" />
            <h2 className="text-base font-semibold text-foreground">Logs del panel</h2>
          </div>
          <div className="rounded-xl bg-secondary border border-border p-4 h-48 overflow-y-auto font-mono text-xs text-muted-foreground space-y-1">
            {logs.map((log, i) => (
              <div key={i} className="leading-relaxed">{log}</div>
            ))}
          </div>
        </div>

        {/* ── Info del VPS ─────────────────────────────────────────────────── */}
        <div className="rounded-2xl border border-border bg-card p-6 space-y-3">
          <div className="flex items-center gap-3">
            <Users className="h-5 w-5 text-accent" />
            <h2 className="text-base font-semibold text-foreground">Configuración VPS</h2>
          </div>
          <div className="rounded-xl bg-secondary border border-border p-4 font-mono text-xs text-muted-foreground space-y-1.5">
            <p><span className="text-accent">VPS_URL</span>=http://TU-IP:3000</p>
            <p><span className="text-accent">VPS_API_KEY</span>=tu_clave_secreta</p>
            <p className="text-muted-foreground/50 pt-1">
              # Agrega estas variables en Vercel → Settings → Environment Variables
            </p>
          </div>
        </div>

      </div>
    </div>
  )
}
