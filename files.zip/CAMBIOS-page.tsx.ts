// ══════════════════════════════════════════════════════════════════
//  CAMBIOS EN app/page.tsx — 3 pasos
// ══════════════════════════════════════════════════════════════════

// ─── PASO 1: Agregar el import arriba del todo (junto a los demás imports) ───

import { BotSection } from "@/components/bot/bot-section"


// ─── PASO 2: En ApiSection, agregar el botón de Bot en el nav ────────────────
// Busca esta parte en la función ApiSection (nav de arriba):
//
//   <button onClick={onGoMovies} ...>
//     <Film ... />
//     <span>Peliculas</span>
//   </button>
//
// Y agrega este botón ANTES del de Peliculas:

<button
  onClick={onGoBot}
  className="group flex items-center gap-2 rounded-lg border border-border bg-secondary px-4 py-2 text-sm font-medium text-foreground transition-all hover:border-accent hover:bg-accent/10"
>
  <Bot className="h-4 w-4 text-accent" />
  <span className="hidden sm:inline">Bot</span>
</button>


// ─── PASO 3: Reemplazar el ROOT al final del archivo ────────────────────────
// Reemplaza la última función HomePage() con esta:

export default function HomePage() {
  const [view, setView] = useState<"api" | "movies" | "bot">("api")

  const goApi = () => { window.scrollTo(0, 0); setView("api") }

  if (view === "movies") return <MoviesSection onGoApi={goApi} />
  if (view === "bot")    return <BotSection    onGoApi={goApi} />

  return (
    <ApiSection
      onGoMovies={() => { window.scrollTo(0, 0); setView("movies") }}
      onGoBot={() => { window.scrollTo(0, 0); setView("bot") }}
    />
  )
}


// ─── Y actualiza la firma de ApiSection para recibir onGoBot ────────────────
// Cambia:
//   function ApiSection({ onGoMovies }: { onGoMovies: () => void })
// Por:
//   function ApiSection({ onGoMovies, onGoBot }: { onGoMovies: () => void; onGoBot: () => void })
