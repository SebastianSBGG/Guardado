// ══════════════════════════════════════════════════════════════════
//  api-server.js — Agrega esto a tu VPS junto a Bailey
//  Ejecutar: node api-server.js
//  O mejor:  integrarlo en tu index.js principal de Bailey
// ══════════════════════════════════════════════════════════════════

const express = require("express")
const app = express()
app.use(express.json())

// ── Variables globales que Bailey debe llenar ─────────────────────
// Estas las conectas con tu instancia de Bailey real
let botStatus = {
  online: true,
  connected: false,
  qr: null,           // string base64 del QR
  uptime: 0,
  messagesHandled: 0,
  activeChats: 0,
}

// Actualiza el uptime cada segundo
setInterval(() => { botStatus.uptime++ }, 1000)

// ── Middleware: clave API simple ──────────────────────────────────
const API_KEY = process.env.VPS_API_KEY || "mi_clave_secreta"

app.use((req, res, next) => {
  const key = req.headers["x-api-key"]
  // Si no hay clave configurada, permite todo (para desarrollo)
  if (API_KEY === "mi_clave_secreta") return next()
  if (key !== API_KEY) return res.status(401).json({ error: "No autorizado" })
  next()
})

// ── CORS para Vercel ──────────────────────────────────────────────
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*")
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, x-api-key")
  next()
})

// ── Endpoints ─────────────────────────────────────────────────────

// Estado del bot
app.get("/api/status", (req, res) => {
  res.json(botStatus)
})

// Enviar mensaje (conectar con Bailey)
app.post("/api/send", async (req, res) => {
  const { numero, mensaje } = req.body
  if (!numero || !mensaje) {
    return res.status(400).json({ ok: false, error: "Faltan campos" })
  }
  try {
    // ── AQUÍ conectas con tu instancia de Bailey ──────────────────
    // Ejemplo: await sock.sendMessage(`${numero}@s.whatsapp.net`, { text: mensaje })
    // Por ahora retorna ok para que puedas probar el panel
    console.log(`[API] Enviar a ${numero}: ${mensaje}`)
    botStatus.messagesHandled++
    res.json({ ok: true })
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message })
  }
})

// ── Función para llamar desde Bailey ─────────────────────────────
// En tu index.js de Bailey, importa este módulo y usa estas funciones:

function setBotConnected(qrBase64OrNull) {
  if (qrBase64OrNull) {
    // Mostrando QR
    botStatus.connected = false
    botStatus.qr = qrBase64OrNull
  } else {
    // Conectado exitosamente
    botStatus.connected = true
    botStatus.qr = null
  }
}

function incrementMessages() {
  botStatus.messagesHandled++
}

function setActiveChats(n) {
  botStatus.activeChats = n
}

// ── Iniciar servidor ──────────────────────────────────────────────
const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
  console.log(`[API] Servidor corriendo en puerto ${PORT}`)
})

module.exports = { setBotConnected, incrementMessages, setActiveChats }

// ══════════════════════════════════════════════════════════════════
//  CÓMO INTEGRARLO CON BAILEY (en tu index.js principal)
// ══════════════════════════════════════════════════════════════════
//
//  const { setBotConnected, incrementMessages } = require("./api-server")
//
//  // Cuando Bailey genera el QR:
//  sock.ev.on("connection.update", ({ qr, connection }) => {
//    if (qr) {
//      const QRCode = require("qrcode")
//      QRCode.toDataURL(qr).then(url => {
//        const base64 = url.replace("data:image/png;base64,", "")
//        setBotConnected(base64)
//      })
//    }
//    if (connection === "open") setBotConnected(null)
//    if (connection === "close") botStatus.connected = false
//  })
//
//  // Cuando llega un mensaje:
//  sock.ev.on("messages.upsert", () => {
//    incrementMessages()
//  })
// ══════════════════════════════════════════════════════════════════
